# Hostelite
A hostel management app using flutter where the complains of students and their exit or entry timing reaches directly to the administration.

### Screenshots of App

<img src="https://github.com/SrijanShovit/Hostelite/blob/main/Screenshots/StudentHomeScreen.jpeg" alt="android" width="220" height="500"/>
Student Home Screen
