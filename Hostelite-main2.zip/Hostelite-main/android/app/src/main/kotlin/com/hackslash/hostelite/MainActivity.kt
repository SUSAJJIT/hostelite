package com.hackslash.hostelite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
